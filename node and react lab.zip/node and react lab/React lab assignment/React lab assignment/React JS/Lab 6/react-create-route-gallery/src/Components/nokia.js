import React, { Component } from 'react';

import Nokia_1 from '../img/Nokia_1.jpeg'
import Nokia_105 from '../img/Nokia_105.jpeg'
import Nokia_DS from '../img/Nokia_DS.jpeg'
import Nokia_TA from '../img/Nokia_TA.jpeg'

class Nokia extends Component {
    constructor(props) {
        super(props);
        this.state = { 
            imgs: [ Nokia_1, Nokia_105, Nokia_DS, Nokia_TA ]
         }
    }
    render() { 
        let images = this.state.imgs.map((image,index) => {
             return <img className="img-thumbnail" width="200px" height="400px" src={image} alt={index+1} key={index}/>
        })
        return ( 
            <div>
            <h3>Nokia</h3>
            {images}
            </div>
         );
    }
}
 
export default Nokia;