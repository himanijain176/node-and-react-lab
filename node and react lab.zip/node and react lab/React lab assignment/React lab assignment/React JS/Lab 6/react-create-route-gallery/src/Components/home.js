import React from 'react';

const Home = () => {
    return (
        <h2>Mobile Gallery</h2>
    )
}

export default Home