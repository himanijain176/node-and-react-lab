import React, { Component } from 'react';
import PropTypes from 'prop-types'

class MovieList extends Component {
  render() {

    var movieList=this.props.movies;

    var row=movieList.map(function(movie,index){
      return (
      <tr key={index}>
        <td><img src={movie.imageName} alt={movie.movieName} width='300' height='400'/></td>
        <td>{movie.movieName}</td>
        <td>Rs. {movie.ticketPrice}</td>
      </tr>
      );
    });

    return (
      <table border="1">
        <thead>
          <tr>
            <th>Image Name</th>
            <th>Movie Name</th>
            <th>Ticket Price</th>
          </tr>
        </thead>
        <tbody>
          {row}
       </tbody>
      </table>
    );
  }
}

export default MovieList;

MovieList.defaultProps={
  movies:[
    {
      movieName:'Default',
      imageName:'Default',
      ticketPrice:100
    }
  ]
}

MovieList.propTypes={
  movies:PropTypes.arrayOf(PropTypes.shape({
  imageName:PropTypes.string,
  movieName:PropTypes.string,
  ticketPrice:PropTypes.number.isRequired}))
}