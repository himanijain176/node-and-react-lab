import React, { Component } from 'react';

class MovieList extends Component {
  render() {
    return (
      <table border="1">
        <thead>
          <tr>
            <th>Image Name</th>
            <th>Movie Name</th>
            <th>Ticket Price</th>
          </tr>
        </thead>
        <tbody>
          <tr>
            <td> <img src={this.props.movies[0].imageName} width='100' height='175' alt='HarryPotter'/></td>
            <td>{this.props.movies[0].movieName}</td>
            <td>{this.props.movies[0].ticketPrice}</td>
          </tr>

        <tr>
            <td> <img src={this.props.movies[1].imageName} width='100' height='175' alt='Avengers'/></td>
            <td>{this.props.movies[1].movieName}</td>
            <td>{this.props.movies[1].ticketPrice}</td>
        </tr>
       </tbody>
      </table>
    );
  }
}

export default MovieList;
