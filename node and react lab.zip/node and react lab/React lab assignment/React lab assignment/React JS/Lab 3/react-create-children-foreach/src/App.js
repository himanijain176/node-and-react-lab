import React, { Component } from 'react';
import './App.css';

class App extends Component {
  
  render() {
    var children=this.props.children;
    var count=0;
    return (
      <div className="App">

        <h1>React.Children.forEach</h1>

        {React.Children.forEach(children, (child,i)=>{
          count++;
          document.write("<h6>"+i+" . "+child+" => "+child.length+"</h6>");
        })}

        
        <h5>No of strings available in array-->{count}</h5>
        <h5>Index. String => StringLength</h5>

      </div>
    );
  }
}

export default App;