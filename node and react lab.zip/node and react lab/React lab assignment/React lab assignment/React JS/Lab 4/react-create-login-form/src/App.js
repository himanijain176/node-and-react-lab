import React, { Component } from 'react';
import { Button, FormGroup, FormControl, ControlLabel } from 'react-bootstrap';
import './App.css';

class App extends Component {
  state = {
    userDetails:
    {
      name: "",
      password: "",
      isLoggedIn: false
    },
  }

  /*------Handle the changes in the input fields------*/
  changeName = (e) => {
    const userDetails = Object.assign({}, this.state.userDetails)
    userDetails.name = e.target.value;
    this.setState({ userDetails: userDetails })
  }
  changePwd = (e) => {
    const userDetails = Object.assign({}, this.state.userDetails)
    userDetails.password = e.target.value;
    this.setState({ userDetails: userDetails })
  }



  /*------Handle the login and logout actions------*/
  login = (e) => {
    e.preventDefault()
    const userDetails = Object.assign({}, this.state.userDetails)
    userDetails.isLoggedIn = true
    this.setState({ userDetails: userDetails })
  }

  logout = (e) => {
    e.preventDefault()
    const userDetails = Object.assign({}, this.state.userDetails)
    userDetails.isLoggedIn = false
    userDetails.name = '';
    userDetails.password = '';
    this.setState({ userDetails: userDetails })
  }



  /*------------Conditional Rendering of login Page or User Page-----------*/
  render() {
    if (!this.state.userDetails.isLoggedIn) {
      return (
        <div className="Login">
          <form onSubmit={this.handleSubmit}>

            <FormGroup controlId="uname" bsSize="large">
              <ControlLabel>User Name</ControlLabel>
              <FormControl autoFocus type="text" value={this.state.userDetails.name} onChange={this.changeName.bind(this)} />
            </FormGroup>

            <FormGroup controlId="password" bsSize="large">
              <ControlLabel>Password</ControlLabel>
              <FormControl value={this.state.userDetails.password} onChange={this.changePwd.bind(this)} type="password" />
            </FormGroup>

            <Button block bsSize="large" type="submit" onClick={this.login.bind(this)}>Login
          </Button>

          </form>
        </div>
      );
    }



    else {
      return (
        <div>
          <h1>Welcome {this.state.userDetails.name}</h1>
          <button onClick={this.logout.bind(this)}>LogOut</button>
        </div>
      );
    }
  }
}

export default App;
