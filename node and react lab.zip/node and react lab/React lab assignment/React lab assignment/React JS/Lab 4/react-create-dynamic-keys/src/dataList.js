import React, { Component } from 'react';

class DataList extends Component {
 
    createElement(item){
        return(<option key={item.key}>{item.text}</option>)
    }
   
    render(){
        var listEntries = this.props.text;
        var listItem = listEntries.map(this.createElement)

        return (
            <select className= "list">
            {listItem}
            </select>
        )
    }

}
export default DataList;
