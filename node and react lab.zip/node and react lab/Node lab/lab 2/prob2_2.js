var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("lab2db");
  dbo.collection("ProductData").find({}).toArray(function(err, result) {
    if (err) throw err;
    console.log("*********Displaying data from ProductData Collection.**********")
    console.log(result);
    db.close();
  });
});