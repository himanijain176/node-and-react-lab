var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("lab2db");
  dbo.collection("ProductData").find({"ProdId":2}).toArray(function(err, result) {
    if (err) throw err;
    console.log("*********Fetching product details for product having product id 2**********")
    console.log(result);
    db.close();
  });
});