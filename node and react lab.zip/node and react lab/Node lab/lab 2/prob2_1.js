var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/lab2db";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("lab2db");
  dbo.createCollection("ProductData", function(err, res) {
    if (err) throw err;
    console.log("Collection created!");
    var myobj = [
        { ProdId: 1, ProdName: "Leaf Rake",ProdCost:90,ProdDescrip:"Leaf rake with 48-inch wooden handle." },
        { ProdId: 2, ProdName: "Hammer",ProdCost:3000,ProdDescrip:"Curved claw steel hammer" },
        { ProdId: 3, ProdName: "Saw",ProdCost:500,ProdDescrip:"15-inch steel blade hand saw" },
    ];
    dbo.collection("ProductData").insertMany(myobj, function(err, res) {
    if (err) throw err;
    console.log(myobj);
    console.log("3 document inserted");
    db.close();
  });
})
});