//Lab 2.5. Update data based on product id.
var MongoClient = require('mongodb').MongoClient;
var url = "mongodb://localhost:27017/";

MongoClient.connect(url, function(err, db) {
  if (err) throw err;
  var dbo = db.db("lab2db");
  var myquery = {"ProdId":2 };
  var newvalues = { $set: {"ProdCost":4000 } };
  dbo.collection("ProductData").updateOne(myquery, newvalues, function(err, res) {
    if (err) throw err;
    console.log("**********Updating details for product price for product id 2**********")
    console.log("1 document updated");
    db.close();
  });
});