var fs = require('fs')
var http = require('http');
var express = require('express');
var app = express();
var parser = require('body-parser');
app.use(parser.json())
app.route('/AddEmp').post((req,res)=>{
    var e={
            "empId": req.body.id,
            "empName": req.body.name,
            "empSalary": req.body.salary,
            "empAddress": {
                "city": req.body.city,
                "state": req.body.state
            }
        }
        var dat = JSON.parse(fs.readFileSync('employees.json'));
        dat.employee.push(e);
        res.status(200).send(dat);
        fs.writeFileSync('employees.json',JSON.stringify(dat));
})

app.listen(2200, (err, res) => {
    if (err) throw err;
    console.log("Server started");
})