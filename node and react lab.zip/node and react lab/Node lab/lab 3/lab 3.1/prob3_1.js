var fs=require('fs'); 
var http = require('http');
var express=require('express');
var exp=express();
var cors=require('cors');
var parser=require('body-parser');

exp.use(parser.json());
exp.route("/getData").get((req, res) => {
fs.readFile('employees.json', 'utf8', function (err, data) {
if (err) throw err;
//console.log(data);
var json = JSON.parse(data);
for(var e of json.employee)
{
    console.log("**********");
    console.log("Employee ID is: "+e.empId);
   console.log("Employee Name is: "+e.empName);
   console.log("Employee Salary is: "+e.empSalary);
   console.log("Employee city is: "+e.empAddress.city);
   console.log("Employee state is: "+e.empAddress.state);
    console.log("**********");
}
res.status(200).send(json);
})
})
exp.listen(2300,function(err,res){
    console.log("Enabled data");
});