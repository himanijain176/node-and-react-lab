var fs=require('fs'); 
var http = require('http');
var express=require('express');
var exp=express();
var cors=require('cors');
var parser=require('body-parser');

exp.use(parser.json());
exp.route("/DispState/:state").get((req, res) => {
fs.readFile('employees.json', 'utf8', function (err, data) {
if (err) throw err;
//console.log(data);
var json = JSON.parse(data);
var state=req.params['state'];
var empData=[];
for(var e of json.employee)
{
    if(e.empAddress.state==state)
    {
        empData.push(e);
    }
    
}
res.send(empData);
console.log(empData);
})
})
exp.listen(2300,function(err,res){
    console.log("Enabled data");
});