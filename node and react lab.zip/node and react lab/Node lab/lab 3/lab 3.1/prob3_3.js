var fs = require('fs')
var http = require('http');
var express = require('express');
var app = express();
var parser = require('body-parser');
app.use(parser.json())


app.route('/update').put((req, res) => {
    var id = req.body.id;
    var city=req.body.city;
    var jsondata = JSON.parse(fs.readFileSync('employees.json'));
    for (e of jsondata) {
        if (e.empId == id) {
            e.empAddress.city=city;
            break;
        }
    }
    res.status(200).send(e)
    fs.writeFileSync('employees.json',JSON.stringify(jsondata));
})


app.listen(2200, (err, res) => {
    if (err) throw err;
    console.log("Server started");
})