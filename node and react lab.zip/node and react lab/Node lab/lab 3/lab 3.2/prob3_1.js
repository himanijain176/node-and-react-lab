
var fs=require('fs'); 
var http = require('http');
var express=require('express');
var exp=express();
var cors=require('cors');
var parser=require('body-parser');
var MongoClient = require('mongodb').MongoClient;

exp.route('/file2db', cors()).post((req, res)=>{
    console.log('file2db Invoked....');
    var fileData;
    fs.readFile('employees.json', function(err, data) {
        //res.writeHead(200, {'Content-Type': 'text/plain'});
        fileData = JSON.parse(data.toLocaleString());
        console.log(fileData);
        //res.end();
    });

    MongoClient.connect('mongodb://localhost:27017/employeesdb', function(err, dbvar){
        console.log('In Mongo Client',fileData);
        if(err) throw err;
        var coll = dbvar.db('employeesdb'); 
       coll.createCollection("EmployeeData", function(err, res) {       
        coll.collection('EmployeeData').insertMany(fileData, true, function(err, result){
            if(err) throw err;
            console.log('document inserted....');
            res.send(fileData);
            res.end();
            dbvar.close();
        });
        dbvar.close();
    });
})
});exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));


exp.use(parser.json());
exp.route('/getProducts', cors()).get((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',req.body);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find().toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})
