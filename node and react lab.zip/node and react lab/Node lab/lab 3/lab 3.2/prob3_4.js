/**
 * Deleting data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/deleteProduct', cors()).delete((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').deleteOne({"productId": (req.body).productId}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

/**
 * Updating data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/updateProduct', cors()).put((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').update({"productId": (req.body).productId},{$set:{productCost: 405000}}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})

exp.use(cors()).listen(3000, ()=>console.log("RUNNING...."));


