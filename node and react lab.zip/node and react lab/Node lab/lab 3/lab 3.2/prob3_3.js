
/**
 * Getting data based on product id from MongoDB
 */

exp.use(parser.json());
exp.route('/getProduct/id', cors()).post((req, res)=>{

    // res.status(201).send(req.body);
    MongoClient.connect('mongodb://localhost:27017/test', function(err, dbvar){

        console.log('In Mongo Client',(req.body).productId);
        if(err) throw err;
        var coll = dbvar.db('test');
        coll.collection('test').find({"productId": (req.body).productId}).toArray((err, result)=>{
            if (err) throw err;
            console.log('result',result);
            res.send(result);
            dbvar.close();
        })
        dbvar.close();
    });
})
