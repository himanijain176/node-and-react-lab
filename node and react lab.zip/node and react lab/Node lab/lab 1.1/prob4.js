var express = require('express');  
var app = express();
var bodyParser =require('body-parser')

app.get('/', function (req, res) {
   res.sendFile( __dirname + "/form.html" );
});

var urlencodedParser = bodyParser.urlencoded({ extended: true });
app.post('/RegPage',urlencodedParser, function (req, res) {
   var user = req.body.uname;
   var pwd = req.body.pass;
   console.log("Welcome")
  
    postData = "Welcome,<br>Your name is : "+ user+"<br>" +"Your Password is : "+ pwd
   console.log(postData);
   res.send(postData)
   res.end()
});

app.listen(5000,function(){
    console.log("Running")
});