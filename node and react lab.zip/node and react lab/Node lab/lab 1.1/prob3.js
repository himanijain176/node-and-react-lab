var fs = require('fs');

fs.writeFile('myfile1.txt', 'welcome again to node file', function (err) {
  if (err) throw err;
  console.log('Saved!');
});