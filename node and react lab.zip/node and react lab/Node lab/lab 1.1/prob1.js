
var empdata=["himani","vinal","aditya","pooja","harshita","kuldeep"];
for(var a of empdata)
{
    console.log(a);
}
